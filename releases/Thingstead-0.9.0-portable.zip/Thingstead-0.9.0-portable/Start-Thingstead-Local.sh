#!/usr/bin/env bash
# Thingstead — Local launcher (macOS / Linux)
# Runs on 127.0.0.1 — only accessible from this machine.
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
echo "Starting Thingstead (local) on http://127.0.0.1:4173 ..."
node "$DIR/server/server.mjs" --host 127.0.0.1 --port 4173 --distDir "$DIR/dist" --dataDir "$DIR/.thingstead-data" &
SERVER_PID=$!
sleep 1
open "http://127.0.0.1:4173" 2>/dev/null || xdg-open "http://127.0.0.1:4173" 2>/dev/null || true
echo "Thingstead is running. Press Ctrl+C to stop."
wait $SERVER_PID
