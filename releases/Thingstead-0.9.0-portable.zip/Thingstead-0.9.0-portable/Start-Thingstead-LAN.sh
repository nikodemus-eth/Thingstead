#!/usr/bin/env bash
# Thingstead — LAN launcher (macOS / Linux)
# Binds to 0.0.0.0 — accessible from other machines on the same network.
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
LOCAL_IP=$(ipconfig getifaddr en0 2>/dev/null || hostname -I 2>/dev/null | awk '{print $1}')
echo "Starting Thingstead (LAN) on http://${LOCAL_IP:-0.0.0.0}:4173 ..."
node "$DIR/server/server.mjs" --host 0.0.0.0 --port 4173 --distDir "$DIR/dist" --dataDir "$DIR/.thingstead-data" &
SERVER_PID=$!
sleep 1
open "http://127.0.0.1:4173" 2>/dev/null || xdg-open "http://127.0.0.1:4173" 2>/dev/null || true
echo "Thingstead is running. LAN URL: http://${LOCAL_IP:-<your-ip>}:4173"
echo "Press Ctrl+C to stop."
wait $SERVER_PID
